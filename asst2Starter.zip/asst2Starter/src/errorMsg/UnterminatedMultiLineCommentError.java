package errorMsg;

public class UnterminatedMultiLineCommentError extends CompError
{
    public UnterminatedMultiLineCommentError()
    {
        super("unterminated multi line comment");
    }
}
