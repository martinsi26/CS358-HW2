package errorMsg;

public class EmptyCharError extends CompError
{
    public EmptyCharError()
    {
        super("found empty character");
    }
}
